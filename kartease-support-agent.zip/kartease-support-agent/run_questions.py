"""R6 helper: runs the 14 required test questions and prints answer + tools used.
Copy the results into the table in README.md.   Run: python run_questions.py"""
import time

from app import ask, build_agent
from ingest import ingest

QUESTIONS = [
    ("Policy", "How many days do I have to return a phone?"),
    ("Policy", "Can I return earbuds if I just don't like them?"),
    ("Policy", "What is the delivery charge on a ₹350 order?"),
    ("Policy", "If I order at 4 PM, when will it be dispatched?"),
    ("Policy", "Can I use a coupon together with a bank offer?"),
    ("Policy", "How long is Extended Protection and when can I buy it?"),
    ("Policy", "Can I pay cash on delivery for a ₹12,000 order?"),
    ("Order", "Where is my order KE1002?"),
    ("Order", "What is the status of order ke1005?"),
    ("Order", "What is the status of order KE9999?"),
    ("Both", "My return for KE1006 was picked up. When will I get my refund?"),
    ("Both", "I paid cash for KE1009. If I return it, how do I get my money back?"),
    ("None", "Who is the CEO of Google?"),
    ("None", "Write me a poem about Diwali."),
]

if __name__ == "__main__":
    ingest()
    agent = build_agent()
    for number, (kind, question) in enumerate(QUESTIONS, start=1):
        try:
            answer, tools_used = ask(agent, question)
        except Exception as error:
            answer, tools_used = f"ERROR: {error}", []
        print(f"\n#{number} [{kind}] {question}")
        print(f"Answer: {answer}")
        print(f"Tools used: {', '.join(tools_used) or 'none'}")
        time.sleep(4)  # stay under free-tier rate limits
