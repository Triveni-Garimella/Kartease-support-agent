"""Milestones 4-5: the agent and the terminal chat loop.  Run: python app.py"""
from langchain.agents import create_agent
from langchain_google_genai import ChatGoogleGenerativeAI

import config
from tools import order_status_tool, policy_search_tool

SYSTEM_PROMPT = f"""You are KartEase customer support.
- Use the tools to answer. Never guess.
- Use get_order_status for questions about a specific order.
- Use search_policies for questions about returns, refunds, shipping, warranty, payments, COD, coupons and offers.
- If a question needs both an order's details and a policy, use both tools.
- For anything unrelated to KartEase, reply exactly: {config.SORRY_MESSAGE}
Keep answers short and friendly."""


def build_agent():
    llm = ChatGoogleGenerativeAI(model=config.LLM_MODEL)
    return create_agent(
        model=llm,
        tools=[order_status_tool, policy_search_tool],
        system_prompt=SYSTEM_PROMPT,
    )


def ask(agent, question: str, history=None):
    """Return (answer_text, list_of_tool_names_used).
    history = optional earlier messages [{"role": ..., "content": ...}] for memory."""
    messages_in = list(history or []) + [{"role": "user", "content": question}]
    result = agent.invoke({"messages": messages_in})
    messages = result["messages"]
    tools_used = []
    for message in messages:
        for call in getattr(message, "tool_calls", None) or []:
            if call["name"] not in tools_used:
                tools_used.append(call["name"])
    return messages[-1].text, tools_used


def main():
    from ingest import ingest

    ingest()  # builds the knowledge base on first run, reuses it afterwards
    agent = build_agent()
    print("\nKartEase Support Agent - type 'exit' to quit.\n")
    while True:
        question = input("You: ").strip()
        if not question:
            continue
        if question.lower() == "exit":
            print("Goodbye!")
            break
        try:
            answer, tools_used = ask(agent, question)
        except Exception as error:  # e.g. rate limit on the free tier
            print(f"Agent: Something went wrong ({error}). Please try again.\n")
            continue
        print(f"Agent: {answer}")
        print(f"[Tools used: {', '.join(tools_used) if tools_used else 'none'}]\n")


if __name__ == "__main__":
    main()
