"""Shared settings. Everything that may change lives here or in .env."""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()  # reads GOOGLE_API_KEY etc. from .env

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
ORDERS_FILE = BASE_DIR / "orders.csv"
CHROMA_DIR = str(BASE_DIR / "chroma_db")
COLLECTION_NAME = "kartease_policies"

LLM_MODEL = os.getenv("GEMINI_MODEL") or "gemini-3.7-flash"
EMBED_MODEL = os.getenv("GEMINI_EMBED_MODEL") or "gemini-embedding-001"

CHUNK_SIZE = 500      # characters
CHUNK_OVERLAP = 50
TOP_K = 3

SORRY_MESSAGE = "Sorry, I can only help with KartEase orders and policies."
