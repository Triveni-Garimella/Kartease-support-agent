"""Browser chat interface (stretch goal).  Run: python web_app.py
Then open http://127.0.0.1:7860 in your browser.
Also gives the agent conversation memory, so follow-up questions work."""
import gradio as gr

from app import ask, build_agent
from ingest import ingest

ingest()  # build the knowledge base on first run, reuse afterwards
agent = build_agent()

EXAMPLES = [
    "How many days do I have to return a phone?",
    "Where is my order KE1002?",
    "My return for KE1006 was picked up. When will I get my refund?",
    "Can I use a coupon together with a bank offer?",
    "Who is the CEO of Google?",
]


def _text(content) -> str:
    """Gradio may give message content as a string or a list of blocks."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in content
        ).strip()
    return str(content)


def respond(message, history):
    # Turn the chat history into plain messages so the agent remembers earlier turns.
    memory = [
        {"role": turn["role"], "content": _text(turn["content"])}
        for turn in (history or [])
        if turn.get("role") in ("user", "assistant") and _text(turn.get("content"))
    ]
    try:
        answer, tools_used = ask(agent, message, memory)
    except Exception as error:  # rate limit, network problem, bad key ...
        return f"Something went wrong: {error}\n\nPlease try again in a moment."
    return f"{answer}\n\n*Tools used: {', '.join(tools_used) if tools_used else 'none'}*"


demo = gr.ChatInterface(
    fn=respond,
    title="KartEase Support Agent",
    description="Ask about KartEase policies (returns, shipping, warranty, payments) "
    "or check an order such as KE1002.",
    examples=EXAMPLES,
)

if __name__ == "__main__":
    demo.launch()
