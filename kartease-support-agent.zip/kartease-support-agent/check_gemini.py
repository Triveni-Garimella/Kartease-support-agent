"""Milestone 1: confirm the API key works with one Gemini call."""
from langchain_google_genai import ChatGoogleGenerativeAI

import config

llm = ChatGoogleGenerativeAI(model=config.LLM_MODEL)
reply = llm.invoke("Say hello in one short sentence.")
print(reply.text)
