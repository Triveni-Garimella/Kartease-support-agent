"""Milestone 2: load policy docs -> chunk -> embed -> store in Chroma.

Run:  python ingest.py          (builds the store; skips if it already exists)
      python ingest.py --test   (also prints the top 3 chunks for a sample question)
"""
import sys

from langchain_chroma import Chroma
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

import config


def get_vectorstore() -> Chroma:
    """Open (or create) the Chroma collection stored on disk."""
    embeddings = GoogleGenerativeAIEmbeddings(model=config.EMBED_MODEL)
    return Chroma(
        collection_name=config.COLLECTION_NAME,
        embedding_function=embeddings,
        persist_directory=config.CHROMA_DIR,
    )


def ingest() -> Chroma:
    store = get_vectorstore()

    # R1: reuse stored vectors instead of embedding everything again.
    existing = store._collection.count()
    if existing > 0:
        print(f"Chroma already has {existing} chunks - skipping embedding.")
        return store

    loader = DirectoryLoader(
        str(config.DATA_DIR),
        glob="*.md",
        loader_cls=TextLoader,
        loader_kwargs={"encoding": "utf-8"},
    )
    docs = loader.load()
    print(f"Loaded {len(docs)} documents.")

    # Keep only the file name as the source (e.g. returns_and_refunds.md).
    for doc in docs:
        doc.metadata["source"] = doc.metadata["source"].replace("\\", "/").split("/")[-1]

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=config.CHUNK_SIZE, chunk_overlap=config.CHUNK_OVERLAP
    )
    chunks = splitter.split_documents(docs)
    print(f"Split into {len(chunks)} chunks.")

    store.add_documents(chunks)
    print(f"Stored {len(chunks)} chunks in {config.CHROMA_DIR}")
    return store


def retrieval_test(store: Chroma) -> None:
    question = "What is the return window for phones?"
    print(f"\nTop {config.TOP_K} chunks for: {question}\n")
    for doc, score in store.similarity_search_with_score(question, k=config.TOP_K):
        print(f"[{doc.metadata['source']}]  score (distance, lower = closer): {score:.4f}")
        print(doc.page_content.strip(), "\n" + "-" * 60)


if __name__ == "__main__":
    vector_store = ingest()
    if "--test" in sys.argv:
        retrieval_test(vector_store)
