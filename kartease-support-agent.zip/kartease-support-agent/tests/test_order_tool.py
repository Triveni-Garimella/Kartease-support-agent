"""R6: tests for get_order_status. They never call Gemini."""
from tools import get_order_status


def test_known_order():
    assert "Shipped" in get_order_status("KE1002")


def test_lowercase_order_id():
    result = get_order_status("ke1005")
    assert "Processing" in result


def test_unknown_order():
    assert "No order found" in get_order_status("KE9999")


def test_unknown_order_does_not_crash_on_spaces():
    assert "No order found" in get_order_status("  KE0000  ")


def test_cancelled_order_has_no_crash_on_empty_date():
    result = get_order_status("KE1007")
    assert "Cancelled" in result


def test_payment_method_is_returned():
    assert "Cash on Delivery" in get_order_status("KE1009")
