# KartEase Support Agent

A RAG-powered customer support assistant for **KartEase**, a fictional Indian online store (electronics, home & kitchen, clothing). Built as the capstone project for the Agentic AI Bootcamp.

The agent answers customer questions by deciding, on its own, which tool to use:

| Tool | Purpose | Data source |
| --- | --- | --- |
| `search_policies` | RAG over policy documents; answers only from retrieved text and cites the source file | `data/*.md` → Chroma vector store |
| `get_order_status` | Looks up an order's product, status, dates and payment method | `orders.csv` |

For some questions (e.g. "My return for KE1006 was picked up, when is my refund?") it uses **both** tools. For anything unrelated to KartEase it replies:
*"Sorry, I can only help with KartEase orders and policies."*

---

## How it works

```
Customer question (terminal chat)
        │
        ▼
   Agent (Gemini) ── reads tool descriptions ── chooses tool(s)
        │                                   │
        ▼                                   ▼
 search_policies                     get_order_status
 (embed query → Chroma top-3         (read orders.csv, case-insensitive
  chunks → Gemini answers only        match on order ID)
  from context + source file)
        │                                   │
        └──────────────┬────────────────────┘
                       ▼
        Short, friendly final answer + tools used
```

## Tech stack

- **Framework:** LangChain  *(one framework only, as per project rules; change this line if you use LlamaIndex)*
- **LLM:** Google Gemini (free tier) via `langchain_google_genai.ChatGoogleGenerativeAI`
- **Embeddings:** Gemini embeddings via `GoogleGenerativeAIEmbeddings`
- **Vector DB:** Chroma, persisted locally in `chroma_db/`
- **Loading / splitting:** `DirectoryLoader` + `TextLoader`, `RecursiveCharacterTextSplitter` (500 characters, small overlap)
- **Agent:** `create_agent` from `langchain.agents`, tools made with the `@tool` decorator
- **Tests:** pytest

**Why LangChain?** *(Replace with your own reason, e.g. simple synchronous agent API, large community, clear tool decorator.)*

## Project structure

```
kartease-support-agent/
├── data/
│   ├── returns_and_refunds.md
│   ├── shipping_and_delivery.md
│   ├── warranty_and_repairs.md
│   └── payments_and_offers.md
├── orders.csv
├── check_gemini.py        # Milestone 1: sanity check for the API key
├── ingest.py              # Load, chunk, embed, store in Chroma (skips if already stored)
├── tools.py               # get_order_status, search_policies, tool wrappers
├── app.py                 # Terminal chat loop
├── web_app.py             # Browser chat interface (Gradio) with memory
├── run_questions.py       # Runs the 14 required test questions
├── config.py              # Model names, chunk size, top-k
├── tests/
│   └── test_order_tool.py # pytest tests (no Gemini calls)
├── requirements-langchain.txt
├── .env.example
├── .gitignore
├── pytest.ini
├── LICENSE
└── README.md
```

## Setup

**Prerequisites:** Python 3.10+, git, and a free Gemini API key from [Google AI Studio](https://aistudio.google.com/).

```bash
# 1. Clone
git clone https://github.com/<your-username>/kartease-support-agent.git
cd kartease-support-agent

# 2. Virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install the tested package versions
pip install -r requirements-langchain.txt

# 4. Add your API key
cp .env.example .env             # Windows: copy .env.example .env
# open .env and paste your key into GOOGLE_API_KEY (never commit this file)

# 5. Verify Gemini works
python check_gemini.py
```

## Running

```bash
# Build the knowledge base (first run embeds; later runs reuse chroma_db/)
python ingest.py

# Start the chat
python app.py
```

Type your question and press Enter. The answer is followed by the tool(s) used. Type `exit` to quit.

Browser chat page (with conversation memory):

```bash
python web_app.py
```

Then open http://127.0.0.1:7860 in your browser.

Example (terminal):

```
You: Where is my order KE1002?
Agent: Your order KE1002 has shipped and is expected on 2026-10-07.
[Tools used: get_order_status]
```

## Running the tests

```bash
python -m pytest
```

The pytest tests cover `get_order_status` only (known ID, lowercase ID, unknown ID, cancelled order, payment method). They do not call Gemini, so they are fast and use no API quota.

## Agent test results

Run `python run_questions.py` (or ask each question in `python app.py`) and record the result honestly.

| # | Question | Expected | Tool(s) expected | Result |
| --- | --- | --- | --- | --- |
| 1 | How many days do I have to return a phone? | 10 days from delivery | Policy | ☐ Pass / ☐ Fail |
| 2 | Can I return earbuds if I just don't like them? | No (hygiene), unless damaged/defective | Policy | ☐ Pass / ☐ Fail |
| 3 | What is the delivery charge on a ₹350 order? | ₹40 (free from ₹499) | Policy | ☐ Pass / ☐ Fail |
| 4 | If I order at 4 PM, when will it be dispatched? | Next working day (cut-off 2 PM) | Policy | ☐ Pass / ☐ Fail |
| 5 | Can I use a coupon together with a bank offer? | No | Policy | ☐ Pass / ☐ Fail |
| 6 | How long is Extended Protection and when can I buy it? | 1 extra year; within 30 days of delivery | Policy | ☐ Pass / ☐ Fail |
| 7 | Can I pay cash on delivery for a ₹12,000 order? | No, COD only up to ₹10,000 | Policy | ☐ Pass / ☐ Fail |
| 8 | Where is my order KE1002? | Shipped; expected 2026-10-07 | Order | ☐ Pass / ☐ Fail |
| 9 | What is the status of order ke1005? | Processing; expected 2026-10-08 | Order | ☐ Pass / ☐ Fail |
| 10 | What is the status of order KE9999? | No order found | Order | ☐ Pass / ☐ Fail |
| 11 | My return for KE1006 was picked up. When will I get my refund? | Quality check, then 5–7 working days to debit card | Both | ☐ Pass / ☐ Fail |
| 12 | I paid cash for KE1009. If I return it, how do I get my money back? | COD; refund to bank account/UPI in 5–7 working days | Both | ☐ Pass / ☐ Fail |
| 13 | Who is the CEO of Google? | Sorry message | None | ☐ Pass / ☐ Fail |
| 14 | Write me a poem about Diwali. | Sorry message | None | ☐ Pass / ☐ Fail |

### One fix tried

- **Failed question:** *(fill in)*
- **Change made:** *(better tool description / clearer prompt / chunk size / top-k)*
- **Result after the change:** *(fill in)*

## Known limitations

1. **No conversation memory in the terminal app:** each question is answered independently. Memory works only in the web interface.
2. **Small, fixed knowledge base:** answers depend on 4 policy files and 10 sample orders; retrieval of only the top 3 chunks can miss information spread across several documents.

## Stretch goals (optional)

- **Gradio web chat:** done (`web_app.py`)
- **Conversation memory:** done in `web_app.py` (history is re-sent with each question)

## Security

The API key lives only in `.env`, which is listed in `.gitignore`. Before pushing, confirm with `git status` that `.env` is not tracked.

## License

Released under the [MIT License](LICENSE). The KartEase policy documents and sample orders are fictional training data supplied with the bootcamp starter pack.

## Acknowledgements

Agentic AI Bootcamp capstone case study. Built with LangChain, ChromaDB and Google Gemini.
