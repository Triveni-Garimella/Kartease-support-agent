"""The two tools the agent can use.

The plain functions (get_order_status, search_policies) are kept separate from
the LangChain tool wrappers at the bottom, so pytest can test them directly.
Gemini is only loaded when search_policies is actually called, so the order
tests need no API key.
"""
import csv
from functools import lru_cache

from langchain_core.tools import tool

import config


# --------------------------------------------------------------------------
# Tool 1: order lookup (plain Python, no Gemini)
# --------------------------------------------------------------------------
def get_order_status(order_id: str) -> str:
    """Look up an order by its ID (like KE1002) and return its product, status, dates and payment method."""
    wanted = order_id.strip().upper()
    try:
        with open(config.ORDERS_FILE, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            id_column = reader.fieldnames[0]  # first column holds the order ID
            for row in reader:
                if row[id_column].strip().upper() == wanted:
                    details = "; ".join(
                        f"{key.strip()}: {value.strip()}" for key, value in row.items() if value
                    )
                    return f"Order found - {details}"
    except FileNotFoundError:
        return "The orders file could not be found."
    return f"No order found with ID {order_id.strip()}."


# --------------------------------------------------------------------------
# Tool 2: policy search (RAG)
# --------------------------------------------------------------------------
POLICY_PROMPT = """You are KartEase customer support.
Answer the question using ONLY the context below.
Keep the answer short and friendly.
End with the source file that contains the answer, like: (Source: returns_and_refunds.md).
If the context does not contain the answer, reply exactly:
{sorry}

Context:
{context}

Question: {question}
Answer:"""


@lru_cache(maxsize=1)
def _get_store():
    from ingest import get_vectorstore  # imported lazily: needs the API key

    return get_vectorstore()


@lru_cache(maxsize=1)
def _get_llm():
    from langchain_google_genai import ChatGoogleGenerativeAI

    return ChatGoogleGenerativeAI(model=config.LLM_MODEL)


def search_policies(question: str) -> str:
    """Answer a question about KartEase policies (returns, refunds, shipping, delivery, warranty, payments, COD, coupons) from the policy documents."""
    docs = _get_store().similarity_search(question, k=config.TOP_K)
    if not docs:
        return config.SORRY_MESSAGE

    context = "\n\n".join(
        f"[Source: {d.metadata.get('source', 'unknown')}]\n{d.page_content}" for d in docs
    )
    prompt = POLICY_PROMPT.format(
        sorry=config.SORRY_MESSAGE, context=context, question=question
    )
    answer = _get_llm().invoke(prompt).text.strip()

    if answer.startswith("Sorry"):
        return config.SORRY_MESSAGE

    return answer


# --------------------------------------------------------------------------
# LangChain tool wrappers (the agent chooses tools by reading the docstrings)
# --------------------------------------------------------------------------
order_status_tool = tool(get_order_status)
policy_search_tool = tool(search_policies)
